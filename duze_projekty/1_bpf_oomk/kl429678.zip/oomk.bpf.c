#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_endian.h>


/*
Author: Krzysztof Lembryk
                                -------------------
                                --USEFUL COMMANDS--
                                -------------------
    Copy by ssh:  scp -P 2222 ./oomk.bpf.c root@127.0.0.1:~/bpf_oom_killer/
    #######################################################################
    Where to look for files:
    - kernel functions etc - /usr/src/linux-headers-$(uname -r)/
    - tracepoints - /sys/kernel/debug/tracing 
        check members of tracepoint ```args``` struct: 
        ```bpftrace -vl tracepoint:syscalls:sys_enter_openat```
    - kprobes - file from teacher
    - structs - /usr/src/linux-headers-$(uname -r)/arch/x86/include/asm/ptrace.h 
    - strace - for syscalls
    - ltrace - for library calls (i.e. for rand())
*/

/* ####################### CONSTANTS DEFS #######################*/
// TCP protocol
#define IPPROTO_TCP 6
// fcntl constants
#define F_DUPFD 0	
#define F_DUPFD_CLOEXEC 1030
// Signals
#define SIGKILL 9

#define KILLING_ENABLED 1
#define KILLING_DISABLED 0
#define MAX_ENTRIES 4096
#define ONE_GB (1024ULL * 1024 * 1024)
#define THRESHOLD_NUMBER_OF_RAND_CALLS 100
#define THRESHOLD_NUMBER_OF_OPENED_FD 100
#define THRESHOLD_NUMBER_OF_WRITES 100
#define THRESHOLD_NUMBER_OF_MB_TO_READ (10U * 1024 * 1024)
#define THRESHOLD_NUMBER_OF_THREADS 100
#define THRESHOLD_NUMBER_OF_SENT_TCP_PACKETS 1000

// Global variable (translated into one elem array by compiler) that tells us if we 
// can kill processes (if memory usage is >= 1GB)
// !!! REMEMBER TO USE __sync_* for this variable to prevent DATA RACES !!!
int IS_KILLING_ALLOWED = 0;

//###################################################################################
// 0) Kill only programs with "oomp" in their process name.
//###################################################################################

// Function checks if inside str1 there is 'oomp' substr
static bool oomp_substr_exists_in(const char *str, size_t str_len)
{
    static const char *oomp_str = "oomp";
    static const size_t oomp_len = 4;

    for (size_t i = 0; i < str_len; i++)
    {
        if (str[i] == oomp_str[0])
        {
            for (size_t j = 1; j < oomp_len; j++)
            {

                if (i + j < str_len)
                {
                    if (str[i + j] == oomp_str[j])
                    {
                        if (j >= oomp_len - 1)
                        {

                            return true;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else 
                {
                    return false;
                }
            }
        }
    }
    return false;
}

static bool is_oomp_present()
{
    struct task_struct *task = (void *)bpf_get_current_task();
    char comm[16];
    BPF_CORE_READ_STR_INTO(&comm, task, comm);

    return oomp_substr_exists_in(comm, 16);
}

/* ####################### MAPS and STRUCTDS DEFS #######################*/

struct proc_info {
    __u32 rand_calls_count;
    __u32 used_fd_count;
    __u32 fcntl_op;
    __u32 write_count;
    __u32 read_mb_count;
    __u32 spawned_threads_count;
    __u8 is_tcp_packet;
    __u32 tcp_packet_sent_count;
};

static struct proc_info proc_info_new()
{
    struct proc_info init_value = {
        .rand_calls_count = 0, 
        .used_fd_count = 0,
        .fcntl_op = 0,
        .write_count = 0,
        .read_mb_count = 0,
        .spawned_threads_count = 0,
        .is_tcp_packet = 0,
        .tcp_packet_sent_count = 0,
    };
    
    return init_value;
}

static bool proc_should_be_killed(struct proc_info *ctx)
{
    if (
        ctx->rand_calls_count >= THRESHOLD_NUMBER_OF_RAND_CALLS
        || ctx->used_fd_count >= THRESHOLD_NUMBER_OF_OPENED_FD
        || ctx->write_count >= THRESHOLD_NUMBER_OF_WRITES
        || ctx->read_mb_count >= THRESHOLD_NUMBER_OF_MB_TO_READ
        || ctx->spawned_threads_count >= THRESHOLD_NUMBER_OF_THREADS
        || ctx->tcp_packet_sent_count >= THRESHOLD_NUMBER_OF_SENT_TCP_PACKETS
    )
    {
        return true;
    }
    return false;
}

struct sys_exit_funcs_args {
    __u64 unused;
    int __syscall_nr;
    long ret;
};

// STATE_MAP - in it we will store all information about whether given process
// should be killed or not
// We use LRU map since number of processes's data we can store is limited, and 
// set at the start of the programme, so if we hit our limit LRU will remove least
// used entry 
struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH); 
    __type(key, __u64);
    __type(value, struct proc_info);
    __uint(max_entries, MAX_ENTRIES);
} state_map SEC(".maps");


struct {
    __uint(type, BPF_MAP_TYPE_HASH); 
    __uint(max_entries, 16);
    __type(key, __u32);
    __type(value, __u64);
} sysinfo_map SEC(".maps");


//###################################################################################
// Macros and functions 
//###################################################################################

#define GET_PROC_INFO_OR_RETURN()                                       \
    struct proc_info init_value = proc_info_new();                      \
    struct proc_info *proc_info;                                        \
    __u64 pid_tgid = bpf_get_current_pid_tgid();                        \
                                                                        \
    bpf_map_update_elem(&state_map, &pid_tgid, &init_value, BPF_NOEXIST);    \
    proc_info = bpf_map_lookup_elem(&state_map, &pid_tgid);                  \
                                                                        \
    if (!proc_info) {                                                   \
        return 0;                                                       \
    }                                                                   \
                                                                        \
    int i_can_kill = __sync_fetch_and_add(&IS_KILLING_ALLOWED, 0);

static int handle_opening_new_fd(struct sys_exit_funcs_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        // ret < 0 - new fd wasnt created, we do nothing
        if (ctx->ret >= 0)
        {
            proc_info->used_fd_count += 1;

            if (i_can_kill 
                && proc_should_be_killed(proc_info))
            {
                bpf_map_delete_elem(&state_map, &pid_tgid);
                int ret = bpf_send_signal(SIGKILL);
            }
        }
    }
    return 0;
}

static int handle_writes(struct sys_exit_funcs_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        struct stat statbuf;

        if (ctx->ret >= 0)
        {
            proc_info->write_count += 1;

            if (i_can_kill 
                && proc_should_be_killed(proc_info))
            {
                bpf_map_delete_elem(&state_map, &pid_tgid);
                int ret = bpf_send_signal(SIGKILL);
            }
        }
    }
    return 0;
}

static int handle_counting_read_bytes(struct sys_exit_funcs_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()
        if (ctx->ret >= 0)
        {
            proc_info->read_mb_count += ctx->ret;

            if (i_can_kill 
                && proc_should_be_killed(proc_info))
            {
                bpf_map_delete_elem(&state_map, &pid_tgid);
                int ret = bpf_send_signal(SIGKILL);
            }
        }
    }
    return 0;
}

static int handle_spawning_threads(struct sys_exit_funcs_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()
        if (ctx->ret >= 0)
        {
            proc_info->spawned_threads_count += 1;

            if (i_can_kill 
                && proc_should_be_killed(proc_info))
            {
                bpf_map_delete_elem(&state_map, &pid_tgid);
                int ret = bpf_send_signal(SIGKILL);
            }
        }
    }
    return 0;
}

#define FD_EXIT_HANDLER(name) \
SEC("tracepoint/syscalls/sys_exit_" #name) \
int name##_exit(struct sys_exit_funcs_args *ctx) { \
    return handle_opening_new_fd(ctx); \
}

#define WRITE_TO_FILE_EXIT_HANDLER(name) \
SEC("tracepoint/syscalls/sys_exit_" #name) \
int name##_exit(struct sys_exit_funcs_args *ctx) { \
    return handle_writes(ctx); \
}

#define READ_BYTES_EXIT_HANDLER(name) \
SEC("tracepoint/syscalls/sys_exit_" #name) \
int name##_exit(struct sys_exit_funcs_args *ctx) { \
    return handle_counting_read_bytes(ctx); \
}

#define SPAWN_THREAD_EXIT_HANDLER(name) \
SEC("tracepoint/syscalls/sys_exit_" #name) \
int name##_exit(struct sys_exit_funcs_args *ctx) { \
    return handle_spawning_threads(ctx); \
}

//###################################################################################
// sched_process_exit - we need to check it so that if process exits and we still 
// have its pid in our map, we want to remove this entry from our map since if 
// another process gets this pid, we will have corrupted data for it in our map
//###################################################################################

struct sched_proc_exit_args {
    __u64 unused;
    char comm[16];
    __u32 pid;
    int prio;
    __u8 group_dead;
};

SEC("tracepoint/sched/sched_process_exit")
int check_if_proc_exited(struct sched_proc_exit_args *ctx)
{
    if (is_oomp_present())
    {
        __u64 pid_tgid = bpf_get_current_pid_tgid();;

        struct proc_info *proc_info = bpf_map_lookup_elem(
            &state_map, 
            &pid_tgid);                  
                                                                            
        // If there is no entry in map, this means either we killed this process and
        // removed its entry from map or LRU removed it from map so we dont need to
        // do anything since this pid is no longer in our map
        if (!proc_info) 
        {
            return 0;
        }

        // Otherwise this process ends its execution but he is still in our map, so
        // we need to delete value for this pid from our map, so that if new process
        // with the same pid comes, our map will create a new entry for it
        bpf_map_delete_elem(&state_map, &pid_tgid);
    }
    return 0;
}

//###################################################################################
// 1) Do not kill any program unless at least 1 GB of RAM is being used. 
//###################################################################################

SEC("kprobe/si_meminfo")
int check_ram_usage_entry(void *ctx)
{
    struct sysinfo *sys_info = (struct sysinfo *)PT_REGS_PARM1((struct pt_regs*)ctx);

    // We save our pointer to sys_info struct in our map, so that we can access it 
    // in KRETPROBE, since in kprobe this struct is uninitialized. 
    // In kretprobe's ctx we cannot access this struct, we can only get return value,
    // so we will store pointer to it in our map.
    __u64 sys_info_addr = (__u64)sys_info;
    pid_t pid = bpf_get_current_pid_tgid() >> 32;

    bpf_map_update_elem(
        &sysinfo_map, 
        &pid, 
        &sys_info_addr, 
        BPF_NOEXIST
    );

    return 0;
}

// KRETPROBE - gets ONLY RETURN VALUE, in ctx apart from that is trash
// useful docs: https://docs.ebpf.io/ebpf-library/libbpf/ebpf/BPF_KRETPROBE/
SEC("kretprobe/si_meminfo")
int check_ram_usage_exit(void *ctx)
{
    pid_t pid = bpf_get_current_pid_tgid() >> 32;
    __u64 *sys_info_ptr = bpf_map_lookup_elem(&sysinfo_map, &pid);

    if (!sys_info_ptr)
    {
        return 0;
    }

    // In sysinfo we have freeram, totalram and MEM_UNIT, since there is a MEM_UNIT
    // it means that freeram and totalram are not in bytes, but in mem_units, thus
    // to get sizes in bytes we need to multiply by mem_unit
    struct sysinfo *sys_info = (struct sysinfo *)*sys_info_ptr; 

    __u64 free_ram; 
    __u64 total_ram; 
    __u64 ram_used;
    __u32 mem_unit;
    bpf_probe_read_kernel(&free_ram,  sizeof(free_ram),  &sys_info->freeram);
    bpf_probe_read_kernel(&total_ram, sizeof(total_ram),  &sys_info->totalram);
    bpf_probe_read_kernel(&mem_unit,  sizeof(mem_unit),  &sys_info->mem_unit);

    free_ram = free_ram * (__u64)mem_unit;
    total_ram = total_ram * (__u64)mem_unit;
    ram_used = total_ram - free_ram;

    if (ram_used >= ONE_GB)
    {
        // Read value at a, write b to a, return original value of a
        int was_killing_allowed = __sync_lock_test_and_set(
            &IS_KILLING_ALLOWED, 
            KILLING_ENABLED
        );
    }
    else 
    {
        // Not enough ram is being used, we do not allow killing
        __sync_lock_test_and_set(&IS_KILLING_ALLOWED, KILLING_DISABLED);
    }

    bpf_map_delete_elem(&sysinfo_map, &pid);
    return 0;
}

//###################################################################################
// 2) Programs that use 100 or more file descriptors should be killed. 
//      - from information I could find, below sys calls create file descriptors:
//         create, open, openat, fcntl, dup, pipe, socket
//      - we only need to check if when exiting creation of fd was successful
//###################################################################################

// open invokes sys_cal: my_syscall4(__NR_openat, AT_FDCWD, path, flags, mode);
// which uses openat, thus sys_exit_open is not needed, only openat
FD_EXIT_HANDLER(openat)
FD_EXIT_HANDLER(creat)
FD_EXIT_HANDLER(dup)
// pipe underneath uses pipe2
FD_EXIT_HANDLER(pipe2)
FD_EXIT_HANDLER(socket)

// With fcntl we also need to remember op flag thus enter tracepoint is needed
// and handling exit is a little different, thus we dont use macro here
struct sys_enter_fcntl_args {
    __u64 unused;
    __u32 __syscall_nr;
    __u64 fd;
    __u64 cmd;
    __u64 arg;
};

SEC("tracepoint/syscalls/sys_enter_fcntl")
int fcntl_enter(struct sys_enter_fcntl_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        // We need to remember fcntl command here so that in exit tracepoint we will
        // whether it was F_DUPFD or F_DUPFD_CLOEXEC - they create new fd - other 
        // ops dont do that
        proc_info->fcntl_op = ctx->cmd;
    }
    return 0;
}

SEC("tracepoint/syscalls/sys_exit_fcntl")
int fcntl_exit(struct sys_exit_funcs_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        if (ctx->ret >= 0)
        {
            if (proc_info->fcntl_op == F_DUPFD 
                || proc_info->fcntl_op == F_DUPFD_CLOEXEC)
            {
                proc_info->used_fd_count += 1;

                if (i_can_kill 
                    && proc_should_be_killed(proc_info))
                {
                    bpf_map_delete_elem(&state_map, &pid_tgid);
                    int ret = bpf_send_signal(SIGKILL);
                }
            }
        }
    }
    return 0;
}

// When programme closes its file descriptor this means it no longer uses it so we 
// need to decrement used_fd_count
SEC("tracepoint/syscalls/sys_exit_close")
int close_fd_exit(struct sys_exit_funcs_args *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        if (ctx->ret >= 0 && proc_info->used_fd_count > 0)
        {
            proc_info->used_fd_count -= 1;
        }
    }
    return 0;
}

//###################################################################################
// 3) Programs that write to files 100 times or more should be killed. 
//      - syscalls: write, writev, pwritev, pwritev2, pwrite, pwrite64 
//      - we dont care about write args, only if it was successful
//      - if *write* ret value is >= 0 we count it (even if its 0, write happened
//        just nothing was written)
//###################################################################################

WRITE_TO_FILE_EXIT_HANDLER(write)
WRITE_TO_FILE_EXIT_HANDLER(writev)
WRITE_TO_FILE_EXIT_HANDLER(pwritev)
WRITE_TO_FILE_EXIT_HANDLER(pwritev2)
WRITE_TO_FILE_EXIT_HANDLER(pwrite64)

//###################################################################################
// 4) Programs that read 10 MB or more should be killed.
//      - syscalls: read, readv, preadv, preadv2, pread64
//###################################################################################

READ_BYTES_EXIT_HANDLER(read)
READ_BYTES_EXIT_HANDLER(readv)
READ_BYTES_EXIT_HANDLER(preadv)
READ_BYTES_EXIT_HANDLER(preadv2)
READ_BYTES_EXIT_HANDLER(pread64)

//###################################################################################
// 5) Programs that spawn 100 or more threads should be killed.
//      - syscalls: clone3 (used by pthread_create), clone (old API, but may be used)
//###################################################################################

SPAWN_THREAD_EXIT_HANDLER(clone)
SPAWN_THREAD_EXIT_HANDLER(clone3)

/* #####################################################################################
6) Programs that call the rand() function 100 or more times should be killed.
    rand() needs UPROBE, and using ltrace instead of strace, since strace doesnt show
    anything (we have loop in our programme, but strace stops showing anything new
    after executing prlimit and munmap)

- firstly I found below exmaple: https://getanteon.com/blog/exploring-function-tracing-with-ebpf-and-uprobes/

- thus rand() is in libc, cmd: gcc --print-file-name=libc.a
    - location: /usr/lib/gcc/x86_64-linux-gnu/12/../../../x86_64-linux-gnu/libc.a

- first we find rand symbol from our programme: nm ./oomp_test_rand
    - we get: U rand@GLIBC_2.2.5, U - symbol is undefined

- then we try to find in: nm libc.a | grep "T rand" - gives: 0000000000000000 T rand
    but this doesnt give us much

- from https://stackoverflow.com/questions/5925678/location-of-c-standard-library,
    we get "Most things DON'T link against libc.a, they link against libc.so", so we
    check libc.so, it doesnt work, but libc.so.6 does.
    We do: nm -D ./libc.so.6 | grep "T rand" -> 0000000000040790 T rand@@GLIBC_2.2.5 

- we check our executable, so we use ldd - prints shared object dependencies: 
    ldd -r ./oomp_test_rand 
    - it gives: 0000000000040790 T rand@@GLIBC_2.2.5, 0000000000040790 = 0x40790

- now we have the offset: 0x40790 of rand that we will use in our uprobe, we also 
    have path to libc binary in which rand sits: /usr/lib/x86_64-linux-gnu/libc.so.6

- attaching uprobe based on: https://github.com/libbpf/libbpf-bootstrap/pull/6/changes/37b7fffd5e3993608c00181b800454d67cb3d618
---------------------------------------------------------------------------------
- some useful LINKS found while searching: 
    - good bpf examples: https://github.com/libbpf/libbpf-bootstrap/tree/master/examples/c
    - linux docs: https://docs.kernel.org/trace/uprobetracer.html 
    - https://www.collabora.com/news-and-blog/blog/2019/05/14/an-ebpf-overview-part-5-tracing-user-processes/

#####################################################################################
*/

SEC("uretprobe/libc_rand_exit")
int libc_rand_exit(struct pt_regs *ctx) 
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        proc_info->rand_calls_count += 1;

        if (i_can_kill 
            && proc_should_be_killed(proc_info))
        {
            bpf_map_delete_elem(&state_map, &pid_tgid);
            int ret = bpf_send_signal(SIGKILL);
        }
    }
    return 0;
}

/* 
#####################################################################################
7) Programs that send 1000 or more TCP packets should be killed.

- after checking test_packets I saw that it uses sendto, however tracing sendto is
    not good enough since udp also may use sendto/send, send without flags is the 
    same as write, so it might also not transmit tcp packets.
- then I realised I should trace exact moment when IP packet is being sent:
    firstly I skimmed through: https://developer.ibm.com/articles/au-tcpsystemcalls/#receive, saw tcp_output
- than I used grep on provided by our lecturer kprobes file in search of words like: 
    tcp, tcp_output, output... And I found kprobes: ip_output, ip_local_out,
    __ip_local_out
- then I found yt video: https://www.youtube.com/watch?v=8UmPwVFswvY in which at 
    around 14 min I saw the following stack:
    ip_finish_output2
    __ip_finish_output
    ip_finish_output
    ip_output
    ip_local_out
- then I inspected linux source code and saw that indeed ip_output invokes ip_finish:
    ret_val = NF_HOOK_COND(NFPROTO_IPV4, NF_INET_POST_ROUTING,
				net, sk, skb, indev, dev,
				ip_finish_output,
				!(IPCB(skb)->flags & IPSKB_REROUTED));
- and realised that ip_finish_output2 is invoked last, so its a final point before 
    sending ONE packet; fortunately there is a kprobe:ip_finish_output2

- ip_finish_output2(struct net *net, struct sock *sk, struct sk_buff *skb)
    we will check if packet is TCP in skb->header (first I tried skb->protocol but 
    protocol here means i.e. IPv4, so not the one I'm looking for)


- link about ipv4 socket surveillance: https://douglasmakey.medium.com/ipv4-socket-surveillance-tracing-using-kprobe-kretprobe-and-maps-with-bcc-e865a7bfcda8 

- perf tool for tracing stack of calls: https://www.youtube.com/watch?v=8UmPwVFswvY
#####################################################################################
*/


SEC("kprobe/ip_finish_output2")
int ip_finish_output2_entry(void *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        struct sk_buff *skb = (struct sk_buff *)PT_REGS_PARM3((struct pt_regs*)ctx);

        void *head = BPF_CORE_READ(skb, head); 
        __u16 net_header_offset = BPF_CORE_READ(skb, network_header);

        struct iphdr ip_header = {};

        if (bpf_probe_read_kernel(
                &ip_header, 
                sizeof(ip_header), 
                head + net_header_offset) < 0) 
        {
            return 0;
        }

        proc_info->is_tcp_packet = (ip_header.protocol == IPPROTO_TCP);
    }

    return 0;
}

SEC("kretprobe/ip_finish_output2")
int ip_finish_output2_exit(void *ctx)
{
    if (is_oomp_present())
    {
        GET_PROC_INFO_OR_RETURN()

        if (proc_info->is_tcp_packet)
        {
            int ret_val = PT_REGS_RC((struct pt_regs*)ctx);
            if (ret_val >= 0) /* success */
            {
                proc_info->tcp_packet_sent_count += 1;
                if (i_can_kill 
                    && proc_should_be_killed(proc_info))
                {
                    bpf_map_delete_elem(&state_map, &pid_tgid);
                    bpf_send_signal(SIGKILL);
                }
            }
        }
    }

    return 0;
}

char LICENSE[] SEC("license") = "GPL";